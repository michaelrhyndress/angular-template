# Common 3 Tier - Web UI


## Setting up the Local Environment and Workspace
These steps are taken from [https://angular.io/guide/setup-local](https://angular.io/guide/setup-local)


### Node.js (version 10.9.0 or later)
1. Go to [Nodejs.org](https://nodejs.org/en/) and download the 10.16.0 LTS installer.
1. Run the installer with all features selected and check the box to automatically install the necessary tools.
1. To check your version, run `node -v` in a terminal/console window. Should be v10.16.0
1. **IMPORTANT** There were a few blockers identified when using Nodejs v12.4, so do not use it yet
    * For some reason `npm install` attempts to install node-sass@4.11.0 from 
      [Github](https://github.com/sass/node-sass/releases/) with a URL that returns a 404 even though
      that release is shown. 
      ```
      PS C:\Users\keith.f.ellis\source\repos\dow-vsts\Cloud Services\APM0004101-MSE-Common3T\src\ui-web\Com3T.Web> npm install

      > node-sass@4.11.0 install C:\Users\keith.f.ellis\source\repos\dow-vsts\Cloud Services\APM0004101-MSE-Common3T\src\ui-web\Com3T.Web\node_modules\node-sass
      > node scripts/install.js

      Downloading binary from https://github.com/sass/node-sass/releases/download/v4.11.0/win32-x64-72_binding.node
      Cannot download "https://github.com/sass/node-sass/releases/download/v4.11.0/win32-x64-72_binding.node":

      HTTP error 404 Not Found
      ```
    * Use the command below to see which npm packages used by the UI depend on this version
      ```
      C:\Users\keith.f.ellis\source\repos\dow-vsts\Cloud Services\APM0004101-MSE-Common3T\src\ui-web\Com3T.Web> npm ls node-sass
      com3-t-web@0.0.0 C:\Users\keith.f.ellis\source\repos\dow-vsts\Cloud Services\APM0004101-MSE-Common3T\src\ui-web\Com3T.Web
      `-- @angular-devkit/build-angular@0.13.8
      `-- UNMET OPTIONAL DEPENDENCY node-sass@4.11.0
      ```
    * [Can't download node-sass on npm install, returns 404 not found](https://github.com/material-components/material-components-web-codelabs/issues/28)
    * [[Unsupported] Installing node-sass 4.11.0 with Node 12](https://github.com/sass/node-sass/issues/2662)



### npm package manager
1. This is installed by the Node.js installer, but to check your version, run `npm -v` in a terminal/console window. SHould be 6.9.0


### Angular CLI
1. To install the Angular CLI globally, run `npm install -g @angular/cli`



## Development server
1. Change directory to the folder which contains the packages.json file for the Angular app
	* cd "C:\Users\keith.f.ellis\source\repos\dow-vsts\Cloud Services\APM0004101-MSE-Common3T\src\ui-web\Com3T.Web"
1. Run `npm install`
1. Run `ng serve` for a dev server. 
1. Navigate to [http://localhost:4200/](http://localhost:4200/). The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
