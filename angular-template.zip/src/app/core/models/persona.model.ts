export interface Persona {
    name: string;
    displayableId: string;
    initials: string;
}