import { MsalService } from "@azure/msal-angular";

export class User extends MsalService['user'] {}